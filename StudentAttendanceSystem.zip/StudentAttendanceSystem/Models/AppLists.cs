namespace StudentAttendanceSystem.Models
{
    /// <summary>Fixed lists used in dropdowns.</summary>
    public static class AppLists
    {
        public static readonly string[] Programs = { "BCA Regular", "BBA", "B.Com", "MCA" };
        public static readonly int[] Semesters = { 1, 2, 3, 4, 5, 6, 7, 8 };
        public static readonly string[] Divisions = { "A", "B", "C", "D" };
        public static readonly string[] Departments =
            { "Computer Applications", "Mathematics", "Management", "English", "Commerce" };
    }
}
