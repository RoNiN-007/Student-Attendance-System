using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.Models
{
    public class Student
    {
        [Key]
        [Display(Name = "Student ID")]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "Enrollment number is required")]
        [RegularExpression(@"^\d{10,20}$", ErrorMessage = "Enrollment number must have 10 to 20 digits")]
        [Display(Name = "Enrollment No")]
        public string EnrollmentNumber { get; set; }

        [Required(ErrorMessage = "Student name is required")]
        [StringLength(100)]
        [Display(Name = "Student Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Enter a valid email address")]
        [StringLength(100)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid 10-digit mobile number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please select a program")]
        [StringLength(50)]
        public string Program { get; set; }

        [Required(ErrorMessage = "Please select a semester")]
        [Range(1, 8, ErrorMessage = "Semester must be between 1 and 8")]
        public int Semester { get; set; }

        [Required(ErrorMessage = "Please select a division")]
        [StringLength(1)]
        public string Division { get; set; }

        public ICollection<Attendance> Attendances { get; set; } = new List<Attendance>();
    }
}
