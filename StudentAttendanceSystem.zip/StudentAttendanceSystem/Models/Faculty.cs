using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.Models
{
    public class Faculty
    {
        [Key]
        [Display(Name = "Faculty ID")]
        public int FacultyId { get; set; }

        [Required(ErrorMessage = "Faculty name is required")]
        [StringLength(100)]
        [Display(Name = "Faculty Name")]
        public string FacultyName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Enter a valid email address")]
        [StringLength(100)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid 10-digit mobile number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please select a department")]
        [StringLength(100)]
        public string Department { get; set; }

        public ICollection<Subject> Subjects { get; set; } = new List<Subject>();
    }
}
