using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.Models
{
    public class Subject
    {
        [Key]
        [Display(Name = "Subject ID")]
        public int SubjectId { get; set; }

        [Required(ErrorMessage = "Subject code is required")]
        [StringLength(20)]
        [Display(Name = "Subject Code")]
        public string SubjectCode { get; set; }

        [Required(ErrorMessage = "Subject name is required")]
        [StringLength(100)]
        [Display(Name = "Subject Name")]
        public string SubjectName { get; set; }

        [Required(ErrorMessage = "Please select a semester")]
        [Range(1, 8, ErrorMessage = "Semester must be between 1 and 8")]
        public int Semester { get; set; }

        [Required(ErrorMessage = "Please select a faculty")]
        [Display(Name = "Faculty")]
        public int FacultyId { get; set; }          // Foreign key

        public Faculty Faculty { get; set; }        // Navigation property

        public ICollection<Attendance> Attendances { get; set; } = new List<Attendance>();
    }
}
