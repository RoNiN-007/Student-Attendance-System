using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        // Never store the real password - only the salted hash
        [Required]
        public string PasswordHash { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; }

        [Required, StringLength(20)]
        public string Role { get; set; } = "Admin";
    }
}
