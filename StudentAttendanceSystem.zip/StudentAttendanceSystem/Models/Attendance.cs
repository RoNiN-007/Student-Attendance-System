using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.Models
{
    public class Attendance
    {
        [Key]
        public int AttendanceId { get; set; }

        public int StudentId { get; set; }          // FK -> Students
        public Student Student { get; set; }

        public int SubjectId { get; set; }          // FK -> Subjects
        public Subject Subject { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        public bool IsPresent { get; set; }
    }
}
