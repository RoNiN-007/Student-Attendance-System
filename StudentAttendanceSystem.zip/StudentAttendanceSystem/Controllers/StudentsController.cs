using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.Models;

namespace StudentAttendanceSystem.Controllers
{
    public class StudentsController : Controller
    {
        private readonly AppDbContext _context;

        public StudentsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Students  (with search + filters)
        public async Task<IActionResult> Index(string search, string division, int? semester)
        {
            var query = _context.Students.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();
                query = query.Where(s => s.Name.Contains(search)
                                      || s.EnrollmentNumber.Contains(search)
                                      || s.Email.Contains(search)
                                      || s.Phone.Contains(search));
            }

            if (!string.IsNullOrEmpty(division))
                query = query.Where(s => s.Division == division);

            if (semester.HasValue)
                query = query.Where(s => s.Semester == semester.Value);

            ViewBag.Search = search;
            ViewBag.Division = division;
            ViewBag.Semester = semester;

            var students = await query
                .OrderBy(s => s.Semester).ThenBy(s => s.Division).ThenBy(s => s.EnrollmentNumber)
                .ToListAsync();

            return View(students);
        }

        // GET: Students/Create
        public IActionResult Create()
        {
            return View(new Student { Program = "BCA Regular" });
        }

        // POST: Students/Create
        [HttpPost]
        public async Task<IActionResult> Create(
            [Bind("EnrollmentNumber,Name,Email,Phone,Program,Semester,Division")] Student student)
        {
            // Duplicate enrollment number check
            if (await _context.Students.AnyAsync(s => s.EnrollmentNumber == student.EnrollmentNumber))
                ModelState.AddModelError(nameof(Student.EnrollmentNumber), "This enrollment number already exists.");

            if (!ModelState.IsValid)
                return View(student);

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Student added successfully.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Students/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            return View(student);
        }

        // POST: Students/Edit/5
        [HttpPost]
        public async Task<IActionResult> Edit(int id,
            [Bind("StudentId,EnrollmentNumber,Name,Email,Phone,Program,Semester,Division")] Student student)
        {
            if (id != student.StudentId) return NotFound();

            if (await _context.Students.AnyAsync(s => s.EnrollmentNumber == student.EnrollmentNumber
                                                   && s.StudentId != student.StudentId))
                ModelState.AddModelError(nameof(Student.EnrollmentNumber), "This enrollment number already exists.");

            if (!ModelState.IsValid)
                return View(student);

            try
            {
                _context.Update(student);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await _context.Students.AnyAsync(s => s.StudentId == id)) return NotFound();
                throw;
            }

            TempData["Success"] = "Student updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        // POST: Students/Delete/5
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            _context.Students.Remove(student);      // attendance of this student is deleted too (cascade)
            await _context.SaveChangesAsync();

            TempData["Success"] = "Student deleted successfully.";
            return RedirectToAction(nameof(Index));
        }
    }
}
