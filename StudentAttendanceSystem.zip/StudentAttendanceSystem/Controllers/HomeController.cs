using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.ViewModels;

namespace StudentAttendanceSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        // Dashboard
        public async Task<IActionResult> Index()
        {
            var today = DateTime.Today;
            var trendFrom = today.AddDays(-14);

            int totalRecords = await _context.AttendanceRecords.CountAsync();
            int presentCount = await _context.AttendanceRecords.CountAsync(a => a.IsPresent);

            var vm = new DashboardViewModel
            {
                TotalStudents = await _context.Students.CountAsync(),
                TotalFaculty = await _context.FacultyMembers.CountAsync(),
                TotalSubjects = await _context.Subjects.CountAsync(),
                TodayTotal = await _context.AttendanceRecords.CountAsync(a => a.Date == today),
                TodayPresent = await _context.AttendanceRecords.CountAsync(a => a.Date == today && a.IsPresent),
                PresentCount = presentCount,
                AbsentCount = totalRecords - presentCount,
                OverallPercentage = totalRecords == 0 ? 0 : Math.Round(presentCount * 100.0 / totalRecords, 1)
            };

            // Bar chart: attendance % per subject
            var subjectStats = await _context.AttendanceRecords
                .GroupBy(a => a.Subject.SubjectCode)
                .Select(g => new { Code = g.Key, Total = g.Count(), Present = g.Count(a => a.IsPresent) })
                .OrderBy(x => x.Code)
                .ToListAsync();

            foreach (var s in subjectStats)
            {
                vm.SubjectLabels.Add(s.Code);
                vm.SubjectPercentages.Add(Math.Round(s.Present * 100.0 / s.Total, 1));
            }

            // Line chart: daily attendance % for the last 14 days
            var dayStats = await _context.AttendanceRecords
                .Where(a => a.Date >= trendFrom)
                .GroupBy(a => a.Date)
                .Select(g => new { Date = g.Key, Total = g.Count(), Present = g.Count(a => a.IsPresent) })
                .OrderBy(x => x.Date)
                .ToListAsync();

            foreach (var d in dayStats)
            {
                vm.TrendLabels.Add(d.Date.ToString("dd MMM"));
                vm.TrendPercentages.Add(Math.Round(d.Present * 100.0 / d.Total, 1));
            }

            return View(vm);
        }

        [AllowAnonymous]
        public IActionResult Error()
        {
            return View();
        }
    }
}
