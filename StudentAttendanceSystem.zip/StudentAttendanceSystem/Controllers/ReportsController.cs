using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.ViewModels;

namespace StudentAttendanceSystem.Controllers
{
    public class ReportsController : Controller
    {
        private readonly AppDbContext _context;

        public ReportsController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? studentId, int? subjectId, int? semester,
                                               string division, DateTime? fromDate, DateTime? toDate)
        {
            // ---------- 1. Build the filtered query ----------
            var query = _context.AttendanceRecords.AsQueryable();

            if (studentId.HasValue) query = query.Where(a => a.StudentId == studentId.Value);
            if (subjectId.HasValue) query = query.Where(a => a.SubjectId == subjectId.Value);
            if (semester.HasValue) query = query.Where(a => a.Student.Semester == semester.Value);
            if (!string.IsNullOrEmpty(division)) query = query.Where(a => a.Student.Division == division);

            if (fromDate.HasValue)
            {
                var from = fromDate.Value.Date;
                query = query.Where(a => a.Date >= from);
            }
            if (toDate.HasValue)
            {
                var to = toDate.Value.Date;
                query = query.Where(a => a.Date <= to);
            }

            // ---------- 2. Summary ----------
            var vm = new ReportViewModel
            {
                StudentId = studentId,
                SubjectId = subjectId,
                Semester = semester,
                Division = division,
                FromDate = fromDate,
                ToDate = toDate,
                TotalRecords = await query.CountAsync(),
                PresentCount = await query.CountAsync(a => a.IsPresent)
            };
            vm.AbsentCount = vm.TotalRecords - vm.PresentCount;

            // ---------- 3. Student-wise ----------
            var studentData = await query
                .GroupBy(a => new { a.StudentId, a.Student.Name, a.Student.EnrollmentNumber, a.Student.Division })
                .Select(g => new
                {
                    g.Key.Name,
                    g.Key.EnrollmentNumber,
                    g.Key.Division,
                    Total = g.Count(),
                    Present = g.Count(a => a.IsPresent)
                })
                .ToListAsync();

            vm.StudentWise = studentData
                .Select(x => new AttendanceStat
                {
                    Title = x.Name,
                    Subtitle = x.EnrollmentNumber + " | Div " + x.Division,
                    Present = x.Present,
                    Absent = x.Total - x.Present
                })
                .OrderBy(x => x.Title)
                .ToList();

            // ---------- 4. Subject-wise ----------
            var subjectData = await query
                .GroupBy(a => new { a.SubjectId, a.Subject.SubjectCode, a.Subject.SubjectName })
                .Select(g => new
                {
                    g.Key.SubjectCode,
                    g.Key.SubjectName,
                    Total = g.Count(),
                    Present = g.Count(a => a.IsPresent)
                })
                .ToListAsync();

            vm.SubjectWise = subjectData
                .Select(x => new AttendanceStat
                {
                    Title = x.SubjectName,
                    Subtitle = x.SubjectCode,
                    Present = x.Present,
                    Absent = x.Total - x.Present
                })
                .OrderBy(x => x.Subtitle)
                .ToList();

            // ---------- 5. Date-wise ----------
            var dateData = await query
                .GroupBy(a => a.Date)
                .Select(g => new
                {
                    Date = g.Key,
                    Total = g.Count(),
                    Present = g.Count(a => a.IsPresent)
                })
                .OrderByDescending(x => x.Date)
                .ToListAsync();

            vm.DateWise = dateData
                .Select(x => new AttendanceStat
                {
                    Title = x.Date.ToString("dd MMM yyyy"),
                    Subtitle = x.Date.ToString("dddd"),
                    Present = x.Present,
                    Absent = x.Total - x.Present
                })
                .ToList();

            // ---------- 6. Dropdown data ----------
            vm.Students = await _context.Students
                .OrderBy(s => s.EnrollmentNumber)
                .Select(s => new SelectListItem
                {
                    Value = s.StudentId.ToString(),
                    Text = s.EnrollmentNumber + " - " + s.Name,
                    Selected = studentId.HasValue && s.StudentId == studentId.Value
                })
                .ToListAsync();

            vm.Subjects = await _context.Subjects
                .OrderBy(s => s.SubjectCode)
                .Select(s => new SelectListItem
                {
                    Value = s.SubjectId.ToString(),
                    Text = s.SubjectCode + " - " + s.SubjectName,
                    Selected = subjectId.HasValue && s.SubjectId == subjectId.Value
                })
                .ToListAsync();

            return View(vm);
        }
    }
}
