using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.Models;

namespace StudentAttendanceSystem.Controllers
{
    public class SubjectsController : Controller
    {
        private readonly AppDbContext _context;

        public SubjectsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadFaculty(int? selected = null)
        {
            ViewBag.FacultyList = new SelectList(
                _context.FacultyMembers.OrderBy(f => f.FacultyName),
                "FacultyId", "FacultyName", selected);
        }

        public async Task<IActionResult> Index(string search, int? semester)
        {
            var query = _context.Subjects.Include(s => s.Faculty).AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();
                query = query.Where(s => s.SubjectName.Contains(search) || s.SubjectCode.Contains(search));
            }

            if (semester.HasValue)
                query = query.Where(s => s.Semester == semester.Value);

            ViewBag.Search = search;
            ViewBag.Semester = semester;

            return View(await query.OrderBy(s => s.Semester).ThenBy(s => s.SubjectCode).ToListAsync());
        }

        public IActionResult Create()
        {
            LoadFaculty();
            return View(new Subject());
        }

        [HttpPost]
        public async Task<IActionResult> Create(
            [Bind("SubjectCode,SubjectName,Semester,FacultyId")] Subject subject)
        {
            if (await _context.Subjects.AnyAsync(s => s.SubjectCode == subject.SubjectCode))
                ModelState.AddModelError(nameof(Subject.SubjectCode), "This subject code already exists.");

            if (!ModelState.IsValid)
            {
                LoadFaculty(subject.FacultyId);
                return View(subject);
            }

            _context.Subjects.Add(subject);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Subject added successfully.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var subject = await _context.Subjects.FindAsync(id);
            if (subject == null) return NotFound();

            LoadFaculty(subject.FacultyId);
            return View(subject);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id,
            [Bind("SubjectId,SubjectCode,SubjectName,Semester,FacultyId")] Subject subject)
        {
            if (id != subject.SubjectId) return NotFound();

            if (await _context.Subjects.AnyAsync(s => s.SubjectCode == subject.SubjectCode && s.SubjectId != subject.SubjectId))
                ModelState.AddModelError(nameof(Subject.SubjectCode), "This subject code already exists.");

            if (!ModelState.IsValid)
            {
                LoadFaculty(subject.FacultyId);
                return View(subject);
            }

            _context.Update(subject);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Subject updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var subject = await _context.Subjects.FindAsync(id);
            if (subject == null) return NotFound();

            if (await _context.AttendanceRecords.AnyAsync(a => a.SubjectId == id))
            {
                TempData["Error"] = "Cannot delete this subject because attendance has already been recorded for it.";
                return RedirectToAction(nameof(Index));
            }

            _context.Subjects.Remove(subject);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Subject deleted successfully.";
            return RedirectToAction(nameof(Index));
        }
    }
}
