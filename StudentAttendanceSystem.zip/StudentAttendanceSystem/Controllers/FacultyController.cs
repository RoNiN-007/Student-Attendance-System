using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.Models;

namespace StudentAttendanceSystem.Controllers
{
    public class FacultyController : Controller
    {
        private readonly AppDbContext _context;

        public FacultyController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string search)
        {
            var query = _context.FacultyMembers.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();
                query = query.Where(f => f.FacultyName.Contains(search)
                                      || f.Email.Contains(search)
                                      || f.Department.Contains(search));
            }

            ViewBag.Search = search;
            return View(await query.OrderBy(f => f.FacultyName).ToListAsync());
        }

        public IActionResult Create()
        {
            return View(new Faculty());
        }

        [HttpPost]
        public async Task<IActionResult> Create(
            [Bind("FacultyName,Email,Phone,Department")] Faculty faculty)
        {
            if (await _context.FacultyMembers.AnyAsync(f => f.Email == faculty.Email))
                ModelState.AddModelError(nameof(Faculty.Email), "A faculty with this email already exists.");

            if (!ModelState.IsValid)
                return View(faculty);

            _context.FacultyMembers.Add(faculty);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Faculty added successfully.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var faculty = await _context.FacultyMembers.FindAsync(id);
            if (faculty == null) return NotFound();

            return View(faculty);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id,
            [Bind("FacultyId,FacultyName,Email,Phone,Department")] Faculty faculty)
        {
            if (id != faculty.FacultyId) return NotFound();

            if (await _context.FacultyMembers.AnyAsync(f => f.Email == faculty.Email && f.FacultyId != faculty.FacultyId))
                ModelState.AddModelError(nameof(Faculty.Email), "A faculty with this email already exists.");

            if (!ModelState.IsValid)
                return View(faculty);

            _context.Update(faculty);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Faculty updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var faculty = await _context.FacultyMembers.FindAsync(id);
            if (faculty == null) return NotFound();

            // Foreign-key protection: faculty who teaches subjects cannot be deleted
            if (await _context.Subjects.AnyAsync(s => s.FacultyId == id))
            {
                TempData["Error"] = "Cannot delete this faculty because subjects are assigned to them. Reassign the subjects first.";
                return RedirectToAction(nameof(Index));
            }

            _context.FacultyMembers.Remove(faculty);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Faculty deleted successfully.";
            return RedirectToAction(nameof(Index));
        }
    }
}
