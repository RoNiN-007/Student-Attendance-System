using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Data;
using StudentAttendanceSystem.Models;
using StudentAttendanceSystem.ViewModels;

namespace StudentAttendanceSystem.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly AppDbContext _context;

        public AttendanceController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadDropdowns()
        {
            ViewBag.Subjects = _context.Subjects
                .Include(s => s.Faculty)
                .OrderBy(s => s.Semester).ThenBy(s => s.SubjectCode)
                .Select(s => new SelectListItem
                {
                    Value = s.SubjectId.ToString(),
                    Text = s.SubjectCode + " - " + s.SubjectName + " (Sem " + s.Semester + ")"
                })
                .ToList();
        }

        // GET: Attendance/Mark?date=...&subjectId=...&division=...
        [HttpGet]
        public async Task<IActionResult> Mark(DateTime? date, int? subjectId, string division)
        {
            LoadDropdowns();

            var model = new AttendanceMarkViewModel
            {
                Date = (date ?? DateTime.Today).Date,
                SubjectId = subjectId,
                Division = division
            };

            // Show students only after subject + division are chosen
            if (subjectId.HasValue && !string.IsNullOrEmpty(division))
            {
                var subject = await _context.Subjects.FindAsync(subjectId.Value);
                if (subject == null) return NotFound();

                model.SubjectName = subject.SubjectName;

                // Students of the same semester and division as the subject
                var students = await _context.Students
                    .Where(s => s.Semester == subject.Semester && s.Division == division)
                    .OrderBy(s => s.EnrollmentNumber)
                    .ToListAsync();

                // Existing attendance (if already marked) is pre-filled for editing
                var existing = await _context.AttendanceRecords
                    .Where(a => a.SubjectId == subjectId.Value && a.Date == model.Date)
                    .ToListAsync();

                model.AlreadyMarked = existing.Any(e => students.Any(s => s.StudentId == e.StudentId));

                foreach (var s in students)
                {
                    var record = existing.FirstOrDefault(e => e.StudentId == s.StudentId);
                    model.Rows.Add(new AttendanceRow
                    {
                        StudentId = s.StudentId,
                        EnrollmentNumber = s.EnrollmentNumber,
                        StudentName = s.Name,
                        IsPresent = record == null || record.IsPresent   // default: Present
                    });
                }
            }

            return View(model);
        }

        // POST: Attendance/Mark
        [HttpPost]
        public async Task<IActionResult> Mark(AttendanceMarkViewModel model)
        {
            var date = model.Date.Date;

            if (date > DateTime.Today)
            {
                TempData["Error"] = "Attendance cannot be marked for a future date.";
                return RedirectToAction(nameof(Mark), new { date = date.ToString("yyyy-MM-dd"), subjectId = model.SubjectId, division = model.Division });
            }

            if (!model.SubjectId.HasValue || model.Rows == null || model.Rows.Count == 0)
            {
                TempData["Error"] = "No students to save. Please select subject and division.";
                return RedirectToAction(nameof(Mark));
            }

            int subjectId = model.SubjectId.Value;
            var studentIds = model.Rows.Select(r => r.StudentId).ToList();

            // Records that already exist for this subject + date  -> UPDATE, never duplicate
            var existing = await _context.AttendanceRecords
                .Where(a => a.SubjectId == subjectId && a.Date == date && studentIds.Contains(a.StudentId))
                .ToListAsync();

            int added = 0, updated = 0;

            foreach (var row in model.Rows)
            {
                var record = existing.FirstOrDefault(e => e.StudentId == row.StudentId);

                if (record == null)
                {
                    _context.AttendanceRecords.Add(new Attendance
                    {
                        StudentId = row.StudentId,
                        SubjectId = subjectId,
                        Date = date,
                        IsPresent = row.IsPresent
                    });
                    added++;
                }
                else
                {
                    record.IsPresent = row.IsPresent;
                    updated++;
                }
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                // Safety net: the unique index (StudentId, SubjectId, Date) rejected a duplicate
                TempData["Error"] = "Duplicate attendance detected. Nothing was saved.";
                return RedirectToAction(nameof(Mark), new { date = date.ToString("yyyy-MM-dd"), subjectId, division = model.Division });
            }

            TempData["Success"] = updated == 0
                ? $"Attendance saved for {added} students."
                : $"Attendance saved: {added} new and {updated} existing records updated (no duplicates created).";

            return RedirectToAction(nameof(Mark), new { date = date.ToString("yyyy-MM-dd"), subjectId, division = model.Division });
        }
    }
}
