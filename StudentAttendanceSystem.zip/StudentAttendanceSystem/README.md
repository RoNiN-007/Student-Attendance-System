# Student Attendance & Management System

**Developed by:** Aditya Kumar Roy
**Course:** BCA Regular | **Division:** B | **Subject:** .NET
**Enrollment No:** 2405101010001

ASP.NET Core MVC (.NET 8) + Entity Framework Core + SQL Server + Bootstrap 5

---

## 1. Requirements
- Visual Studio 2022 (17.8 or newer) with the **ASP.NET and web development** workload
- .NET 8 SDK (installed with Visual Studio 2022)
- SQL Server LocalDB (installed with Visual Studio) **or** SQL Server Express
- Internet connection (Bootstrap, Bootstrap Icons, Chart.js and jQuery load from CDN)

## 2. Open the project
1. Extract the ZIP.
2. Double-click `StudentAttendanceSystem.csproj` (Visual Studio 2022 opens it and creates a solution).
   - Or: File > Open > Project/Solution > select the `.csproj` file.

### If you want to create it from scratch instead
1. File > New > Project > **ASP.NET Core Web App (Model-View-Controller)** > Next.
2. Project name: `StudentAttendanceSystem` > Next.
3. Framework: **.NET 8.0 (Long Term Support)**, Authentication: None, HTTPS: ticked > Create.
4. Delete the default `HomeController`, `Views/Home`, `Views/Shared`, and `Models/ErrorViewModel.cs`.
5. Copy all folders/files from this project into yours (keep the same folder names) and replace `Program.cs`, `appsettings.json` and the `.csproj` package list.

## 3. NuGet packages
(Already listed in the `.csproj`; Visual Studio restores them automatically.)

| Package | Version |
|---|---|
| Microsoft.EntityFrameworkCore.SqlServer | 8.0.11 |
| Microsoft.EntityFrameworkCore.Tools | 8.0.11 |
| Microsoft.EntityFrameworkCore.Design | 8.0.11 |

To install manually: Tools > NuGet Package Manager > Package Manager Console
```
Install-Package Microsoft.EntityFrameworkCore.SqlServer -Version 8.0.11
Install-Package Microsoft.EntityFrameworkCore.Tools -Version 8.0.11
Install-Package Microsoft.EntityFrameworkCore.Design -Version 8.0.11
```

## 4. SQL Server and connection string
Open `appsettings.json`. Default (LocalDB, works with Visual Studio out of the box):
```
Server=(localdb)\MSSQLLocalDB;Database=StudentAttendanceDB;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True
```
For SQL Server Express use `Server=.\\SQLEXPRESS;...` and for full SQL Server use `Server=YOUR-PC-NAME;...`
(In JSON a backslash must be written as `\\`.)

To check the server name: View > SQL Server Object Explorer.

## 5. Create the database with EF Core migrations
Tools > NuGet Package Manager > **Package Manager Console**, then:
```
Add-Migration InitialCreate
Update-Database
```
(Optional shortcut: if you skip migrations, `Program.cs` calls `EnsureCreated()` and creates the tables automatically. Use ONE method, not both.)

The first run also inserts the demo data (admin user, 5 faculty, 6 subjects, 12 students and sample attendance).

## 6. Run
Press **F5** (or Ctrl+F5). The browser opens the login page.

**Login:** `admin`  /  `Admin@123`

## 7. Project structure
```
StudentAttendanceSystem
|-- Program.cs                  App start-up, services, authentication, middleware
|-- appsettings.json            Connection string and settings
|-- Controllers/                Handle requests (C of MVC)
|   |-- AccountController.cs    Login / Logout
|   |-- HomeController.cs       Dashboard
|   |-- StudentsController.cs   Student CRUD + search
|   |-- FacultyController.cs    Faculty CRUD
|   |-- SubjectsController.cs   Subject CRUD
|   |-- AttendanceController.cs Mark attendance (duplicate-safe)
|   |-- ReportsController.cs    Reports with filters
|-- Models/                     Database entities (M of MVC)
|   |-- User, Student, Faculty, Subject, Attendance, AppLists
|-- ViewModels/                 Classes shaped for a specific screen
|-- Data/
|   |-- AppDbContext.cs         EF Core context, keys, relations, unique indexes
|   |-- DbSeeder.cs             Demo data
|-- Services/
|   |-- PasswordHelper.cs       PBKDF2 password hashing
|-- Views/                      Razor pages (V of MVC)
|   |-- Shared/_Layout.cshtml   Sidebar + navbar + alerts
|   |-- Account, Home, Students, Faculty, Subjects, Attendance, Reports
|-- wwwroot/
    |-- css/site.css            Custom styles
    |-- js/site.js              Delete confirmation, phone digits-only
```

## 8. Viva quick notes
- **MVC**: Model = data classes, View = Razor pages, Controller = logic that connects them.
- **EF Core**: ORM; C# classes become SQL tables; LINQ replaces SQL queries.
- **Migrations**: version-control for the database schema (`Add-Migration`, `Update-Database`).
- **Password security**: PBKDF2 + random salt (never plain text).
- **Authentication**: cookie authentication; global `[Authorize]` filter protects all pages except login.
- **Duplicate attendance**: (1) controller updates an existing record instead of inserting, (2) unique index on (StudentId, SubjectId, Date) in the database.
- **Duplicate enrollment**: checked in the controller and a unique index on `EnrollmentNumber`.
- **CSRF**: `AutoValidateAntiforgeryToken` on every POST.
- **Relationships**: Faculty 1-* Subjects, Student 1-* Attendance, Subject 1-* Attendance.

## 9. Troubleshooting
| Problem | Fix |
|---|---|
| Cannot connect to SQL Server | Check server name in `appsettings.json`; start LocalDB: `sqllocaldb start MSSQLLocalDB` |
| `Add-Migration` not recognised | Install `Microsoft.EntityFrameworkCore.Tools`; select the project as Default project in the console |
| Tables already exist error | Drop the database (`Drop-Database`) and run `Update-Database` again |
| Charts / styling missing | Internet is needed for CDN files |
| Forgot login | Delete the database and run again; admin is re-created |
