using StudentAttendanceSystem.Models;
using StudentAttendanceSystem.Services;

namespace StudentAttendanceSystem.Data
{
    /// <summary>Inserts demo data the first time the application runs.</summary>
    public static class DbSeeder
    {
        public static void Seed(AppDbContext db)
        {
            // ---- Admin user (username: admin / password: Admin@123) ----
            if (!db.Users.Any())
            {
                db.Users.Add(new User
                {
                    Username = "admin",
                    PasswordHash = PasswordHelper.Hash("Admin@123"),
                    FullName = "System Administrator",
                    Role = "Admin"
                });
                db.SaveChanges();
            }

            // ---- Faculty ----
            if (!db.FacultyMembers.Any())
            {
                db.FacultyMembers.AddRange(
                    new Faculty { FacultyName = "Prof. Ramesh Sharma", Email = "ramesh.sharma@college.edu", Phone = "9876500001", Department = "Computer Applications" },
                    new Faculty { FacultyName = "Dr. Anita Verma", Email = "anita.verma@college.edu", Phone = "9876500002", Department = "Computer Applications" },
                    new Faculty { FacultyName = "Prof. Sunil Mehta", Email = "sunil.mehta@college.edu", Phone = "9876500003", Department = "Computer Applications" },
                    new Faculty { FacultyName = "Prof. Kavita Singh", Email = "kavita.singh@college.edu", Phone = "9876500004", Department = "Mathematics" },
                    new Faculty { FacultyName = "Dr. Rajiv Nair", Email = "rajiv.nair@college.edu", Phone = "9876500005", Department = "Computer Applications" });
                db.SaveChanges();
            }

            // ---- Subjects (Semester 5) ----
            if (!db.Subjects.Any())
            {
                var f = db.FacultyMembers.OrderBy(x => x.FacultyId).ToList();
                db.Subjects.AddRange(
                    new Subject { SubjectCode = "BCA501", SubjectName = ".NET Programming", Semester = 5, FacultyId = f[0].FacultyId },
                    new Subject { SubjectCode = "BCA502", SubjectName = "Web Technologies", Semester = 5, FacultyId = f[1].FacultyId },
                    new Subject { SubjectCode = "BCA503", SubjectName = "Software Engineering", Semester = 5, FacultyId = f[2].FacultyId },
                    new Subject { SubjectCode = "BCA504", SubjectName = "Discrete Mathematics", Semester = 5, FacultyId = f[3].FacultyId },
                    new Subject { SubjectCode = "BCA505", SubjectName = "Computer Networks", Semester = 5, FacultyId = f[4].FacultyId },
                    new Subject { SubjectCode = "BCA506", SubjectName = "Python Programming", Semester = 5, FacultyId = f[1].FacultyId });
                db.SaveChanges();
            }

            // ---- Students (Semester 5, Division A and B) ----
            if (!db.Students.Any())
            {
                db.Students.AddRange(
                    new Student { EnrollmentNumber = "2405101010001", Name = "Aditya Kumar Roy", Email = "aditya.roy@student.edu", Phone = "9000000001", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010002", Name = "Priya Sharma", Email = "priya.sharma@student.edu", Phone = "9000000002", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010003", Name = "Rahul Verma", Email = "rahul.verma@student.edu", Phone = "9000000003", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010004", Name = "Sneha Patel", Email = "sneha.patel@student.edu", Phone = "9000000004", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010005", Name = "Amit Singh", Email = "amit.singh@student.edu", Phone = "9000000005", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010006", Name = "Neha Gupta", Email = "neha.gupta@student.edu", Phone = "9000000006", Program = "BCA Regular", Semester = 5, Division = "B" },
                    new Student { EnrollmentNumber = "2405101010007", Name = "Rohan Mishra", Email = "rohan.mishra@student.edu", Phone = "9000000007", Program = "BCA Regular", Semester = 5, Division = "A" },
                    new Student { EnrollmentNumber = "2405101010008", Name = "Pooja Yadav", Email = "pooja.yadav@student.edu", Phone = "9000000008", Program = "BCA Regular", Semester = 5, Division = "A" },
                    new Student { EnrollmentNumber = "2405101010009", Name = "Vikas Kumar", Email = "vikas.kumar@student.edu", Phone = "9000000009", Program = "BCA Regular", Semester = 5, Division = "A" },
                    new Student { EnrollmentNumber = "2405101010010", Name = "Anjali Das", Email = "anjali.das@student.edu", Phone = "9000000010", Program = "BCA Regular", Semester = 5, Division = "A" },
                    new Student { EnrollmentNumber = "2405101010011", Name = "Sahil Khan", Email = "sahil.khan@student.edu", Phone = "9000000011", Program = "BCA Regular", Semester = 5, Division = "A" },
                    new Student { EnrollmentNumber = "2405101010012", Name = "Riya Joshi", Email = "riya.joshi@student.edu", Phone = "9000000012", Program = "BCA Regular", Semester = 5, Division = "A" });
                db.SaveChanges();
            }

            // ---- Demo attendance: last 6 working days for first 3 subjects + today for subject 1 ----
            if (!db.AttendanceRecords.Any())
            {
                var rnd = new Random(42);
                var students = db.Students.ToList();
                var subjects = db.Subjects.OrderBy(s => s.SubjectId).Take(3).ToList();

                var pastDates = new List<DateTime>();
                for (int i = 1; pastDates.Count < 6; i++)
                {
                    var d = DateTime.Today.AddDays(-i);
                    if (d.DayOfWeek != DayOfWeek.Saturday && d.DayOfWeek != DayOfWeek.Sunday)
                        pastDates.Add(d);
                }

                foreach (var subject in subjects)
                {
                    foreach (var date in pastDates)
                        foreach (var student in students)
                            db.AttendanceRecords.Add(new Attendance
                            {
                                StudentId = student.StudentId,
                                SubjectId = subject.SubjectId,
                                Date = date,
                                IsPresent = rnd.Next(100) < 80      // about 80 % present
                            });
                }

                // Today's attendance for subject 1 so the dashboard shows data immediately
                foreach (var student in students)
                    db.AttendanceRecords.Add(new Attendance
                    {
                        StudentId = student.StudentId,
                        SubjectId = subjects[0].SubjectId,
                        Date = DateTime.Today,
                        IsPresent = rnd.Next(100) < 85
                    });

                db.SaveChanges();
            }
        }
    }
}
