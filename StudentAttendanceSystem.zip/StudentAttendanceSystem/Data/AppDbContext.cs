using Microsoft.EntityFrameworkCore;
using StudentAttendanceSystem.Models;

namespace StudentAttendanceSystem.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Faculty> FacultyMembers { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Attendance> AttendanceRecords { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Table names
            modelBuilder.Entity<User>().ToTable("Users");
            modelBuilder.Entity<Student>().ToTable("Students");
            modelBuilder.Entity<Faculty>().ToTable("Faculty");
            modelBuilder.Entity<Subject>().ToTable("Subjects");
            modelBuilder.Entity<Attendance>().ToTable("Attendance");

            // Unique constraints
            modelBuilder.Entity<User>().HasIndex(u => u.Username).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.EnrollmentNumber).IsUnique();
            modelBuilder.Entity<Subject>().HasIndex(s => s.SubjectCode).IsUnique();

            // Faculty 1 --- * Subjects   (cannot delete faculty who still teaches subjects)
            modelBuilder.Entity<Subject>()
                .HasOne(s => s.Faculty)
                .WithMany(f => f.Subjects)
                .HasForeignKey(s => s.FacultyId)
                .OnDelete(DeleteBehavior.Restrict);

            // Student 1 --- * Attendance  (deleting a student removes his attendance)
            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.Student)
                .WithMany(s => s.Attendances)
                .HasForeignKey(a => a.StudentId)
                .OnDelete(DeleteBehavior.Cascade);

            // Subject 1 --- * Attendance  (cannot delete subject that has attendance)
            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.Subject)
                .WithMany(s => s.Attendances)
                .HasForeignKey(a => a.SubjectId)
                .OnDelete(DeleteBehavior.Restrict);

            // Store only the date (no time)
            modelBuilder.Entity<Attendance>().Property(a => a.Date).HasColumnType("date");

            // DUPLICATE PREVENTION: one record per student + subject + date
            modelBuilder.Entity<Attendance>()
                .HasIndex(a => new { a.StudentId, a.SubjectId, a.Date })
                .IsUnique();
        }
    }
}
