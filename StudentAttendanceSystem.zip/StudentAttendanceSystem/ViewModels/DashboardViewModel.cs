namespace StudentAttendanceSystem.ViewModels
{
    public class DashboardViewModel
    {
        public int TotalStudents { get; set; }
        public int TotalFaculty { get; set; }
        public int TotalSubjects { get; set; }

        public int TodayPresent { get; set; }
        public int TodayTotal { get; set; }

        public int PresentCount { get; set; }
        public int AbsentCount { get; set; }
        public double OverallPercentage { get; set; }

        // Chart data
        public List<string> SubjectLabels { get; set; } = new();
        public List<double> SubjectPercentages { get; set; } = new();
        public List<string> TrendLabels { get; set; } = new();
        public List<double> TrendPercentages { get; set; } = new();
    }
}
