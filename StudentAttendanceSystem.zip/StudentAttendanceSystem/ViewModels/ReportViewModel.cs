using Microsoft.AspNetCore.Mvc.Rendering;

namespace StudentAttendanceSystem.ViewModels
{
    /// <summary>One row of a report (a student, a subject or a date).</summary>
    public class AttendanceStat
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public int Present { get; set; }
        public int Absent { get; set; }
        public int Total => Present + Absent;
        public double Percentage => Total == 0 ? 0 : Math.Round(Present * 100.0 / Total, 1);
    }

    public class ReportViewModel
    {
        // Filters
        public int? StudentId { get; set; }
        public int? SubjectId { get; set; }
        public int? Semester { get; set; }
        public string Division { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }

        // Dropdown data
        public List<SelectListItem> Students { get; set; } = new();
        public List<SelectListItem> Subjects { get; set; } = new();

        // Summary
        public int TotalRecords { get; set; }
        public int PresentCount { get; set; }
        public int AbsentCount { get; set; }
        public double OverallPercentage =>
            TotalRecords == 0 ? 0 : Math.Round(PresentCount * 100.0 / TotalRecords, 1);

        // Three report tables
        public List<AttendanceStat> StudentWise { get; set; } = new();
        public List<AttendanceStat> SubjectWise { get; set; } = new();
        public List<AttendanceStat> DateWise { get; set; } = new();
    }
}
