using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceSystem.ViewModels
{
    public class AttendanceRow
    {
        public int StudentId { get; set; }
        public string EnrollmentNumber { get; set; }
        public string StudentName { get; set; }
        public bool IsPresent { get; set; } = true;
    }

    public class AttendanceMarkViewModel
    {
        [DataType(DataType.Date)]
        public DateTime Date { get; set; } = DateTime.Today;

        [Required(ErrorMessage = "Please select a subject")]
        public int? SubjectId { get; set; }

        [Required(ErrorMessage = "Please select a division")]
        public string Division { get; set; }

        public string SubjectName { get; set; }
        public bool AlreadyMarked { get; set; }

        public List<AttendanceRow> Rows { get; set; } = new();
    }
}
