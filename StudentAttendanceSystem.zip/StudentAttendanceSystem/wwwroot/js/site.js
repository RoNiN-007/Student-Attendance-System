// Confirmation before delete: any <form data-confirm="message"> asks the user first
document.addEventListener('submit', function (e) {
    var form = e.target;
    var message = form.getAttribute('data-confirm');
    if (message && !confirm(message)) {
        e.preventDefault();
    }
});

// Phone fields accept digits only
document.querySelectorAll('input[name="Phone"]').forEach(function (input) {
    input.addEventListener('input', function () {
        input.value = input.value.replace(/\D/g, '');
    });
});

// Alerts fade away automatically after 5 seconds
setTimeout(function () {
    document.querySelectorAll('.alert-success.alert-dismissible').forEach(function (a) {
        if (window.bootstrap) { bootstrap.Alert.getOrCreateInstance(a).close(); }
    });
}, 5000);
